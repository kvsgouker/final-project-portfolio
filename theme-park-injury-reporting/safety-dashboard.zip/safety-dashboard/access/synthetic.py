# Category	Incidents/Year/Park	Justification
#
# Disney/Universal	~14 (real)	underreported
# Regional thrill parks	20–30	fewer staff, higher risk
# Carnival/touring	30–50+	poor maintenance, no oversight
# Small family parks	5–15	less extreme rides

import random
from datetime import datetime, timedelta

import pandas as pd

from access.Incident import SyntheticIncident
import json
import os
import numpy as np


# Synthetic data support.
USE_SYNTHETIC_DATA = False

def is_fake_mode():
    global USE_SYNTHETIC_DATA
    return USE_SYNTHETIC_DATA

def set_fake_mode(mode: bool):
    global USE_SYNTHETIC_DATA
    USE_SYNTHETIC_DATA = mode

def sample_from_distribution(dist):
    if isinstance(dist, list):
        return random.choice(dist)
    elif isinstance(dist, dict):
        values = list(dist.keys())
        weights = list(dist.values())
        return random.choices(values, weights=weights, k=1)[0]
    else:
        raise ValueError("Distribution must be a list or dict.")


# Multipliers representing attendance level for each year
ATTENDANCE_WEIGHTS = {
    2020: 0.20,
    2021: 0.40,
    2022: 0.75,
    # Note: All others default to 1.0
}


def classify_ride_type(ride_name, theme_park_name, coaster_ids, ride_number):
    ride = str(ride_name).lower()
    park = str(theme_park_name).lower()

    water_keywords = ['splash', 'slide', 'wet', 'falls', 'water', 'beach', 'lagoon', 'river']

    if ride_number in coaster_ids:
        return 'coaster'
    elif any(word in ride or word in park for word in water_keywords):
        return 'water'
    else:
        return 'other'


def compute_fear_factor(df):
    df = df.copy()

    # Normalize and apply nonlinear transformations
    def safe_div(a, b): return a / b if b else 0

    max_speed = df["Speed"].max()
    max_height = df["Height"].max()
    max_drop = df["Drop"].max()
    max_inversions = df["Inversions"].max()
    max_gforce = df["G-force"].max()

    # Nonlinear continuous components
    fear = (
        (df["Speed"] / max_speed).pow(1.5).fillna(0) * 0.25 +
        (df["Height"] / max_height).pow(1.2).fillna(0) * 0.2 +
        (df["Drop"] / max_drop).pow(1.3).fillna(0) * 0.2 +
        (df["Inversions"] / max_inversions).pow(1.8).fillna(0) * 0.15 +
        (df["G-force"] / max_gforce).pow(1.4).fillna(0) * 0.2
    )

    # Extreme ride features: binary multipliers
    extreme_flags = [
        "flying", "spinning", "dive", "motorbike"
    ]

    # Count of "extreme" features
    boost_counts = df[extreme_flags].fillna(0).astype(bool).sum(axis=1)

    # Apply a nonlinear multiplier for each extreme feature
    multiplier = 1.15 ** boost_counts

    # Final fear factor
    fear_factor = (fear * multiplier).clip(0, 1)

    return fear_factor



def random_date(start_year, end_year):
    years = list(range(int(start_year), int(end_year) + 1))
    weights = [ATTENDANCE_WEIGHTS.get(year, 1.0) for year in years]
    normalized = [w / sum(weights) for w in weights]

    selected_year = np.random.choice(years, p=normalized)
    month = random.randint(1, 12)
    day = random.randint(1, 28)  # Safe default to avoid invalid dates

    return f"{selected_year}-{month:02d}-{day:02d}"


def generate_incident_for_ride(ride, park, distributions, coaster_ids):
    ride_type = classify_ride_type(ride["Ride_Name"], park["Park_Name"], coaster_ids, ride["Ride_Number"])

    # Base sampling
    age_group = sample_from_distribution(distributions["age_group"])
    gender = sample_from_distribution(distributions["gender"])
    injury_location = sample_from_distribution(distributions["injury_location"])
    severity = sample_from_distribution(distributions["severity"])
    medical_attention = sample_from_distribution(distributions["medical_attention"])
    injury_type = sample_from_distribution(distributions["injury_type"])
    ride_status = sample_from_distribution(distributions["ride_status"])
    contributing_factor = sample_from_distribution(distributions["contributing_factor"])

    # Salted tweaks
    date = random_date("2014", "2023")
    month = int(date.split("-")[1])
    description = "Normal Incident."
    salt_applied = False

    # Salt 1: Heat-related summer trend
    if month in [6, 7, 8] and age_group in ['60+', 'Under 12']:
        if random.random() < 0.3:
            injury_type = 'Dizziness / Fainting'
            severity = 'Moderate'
            description = 'Guest reported dizziness due to heat.'
            salt_applied = True

    # Water rides → more in summer, more illness/slips
    if not salt_applied and ride_type == 'water' and month in [6, 7, 8]:
        injury_type = random.choices(
            ["Slip / Fall", "Seizure / Illness", injury_type], weights=[0.4, 0.4, 0.2]
        )[0]
        severity = random.choices(["Minor", "Moderate", severity], weights=[0.5, 0.3, 0.2])[0]
        description = "Water incident."
        salt_applied = True

    # Coasters → more high-impact, neck/back/head, higher severity
    if not salt_applied and ride_type == "coaster":
        # Influence injury location
        injury_location = random.choices(
            ["Head", "Neck", "Back", injury_location], weights=[0.3, 0.25, 0.25, 0.2]
        )[0]

        # Severity by age group
        # salting probabilistic, not deterministic — which is good for realism.
        if age_group == "60+":
            severity = random.choices(["Moderate", "Severe", severity], weights=[0.4, 0.4, 0.2])[0]
        elif age_group == "41–60":
            severity = random.choices(["Minor", "Moderate", severity], weights=[0.3, 0.4, 0.3])[0]
        elif age_group == "18–40":
            severity = random.choices(["Minor", severity, "Moderate"], weights=[0.5, 0.3, 0.2])[0]
        else:  # Kids
            severity = random.choices(["Minor", severity], weights=[0.6, 0.4])[0]
        description = "Coaster incident."

    return SyntheticIncident(
        company=park.get("Owner_Name", "Unknown Co."),
        theme_park=park["Park_Name"],
        ride_name=ride["Ride_Name"],
        incident_date=date,
        age_group=age_group,
        gender=gender,
        injury_location=injury_location,
        severity=severity,
        medical_attention=medical_attention,
        injury_type=injury_type,
        ride_status=ride_status,
        contributing_factor=contributing_factor,
        description=description,
        submission_time=datetime.now().isoformat(),
        ride_number=int(ride["Ride_Number"]) if not pd.isna(ride["Ride_Number"]) else None,
        park_number=int(park["Park_Number"]) if not pd.isna(park["Park_Number"]) else None
    )



def generate_incidents(distributions, parks_df, rides_df, coasters_df, count=1000):
    incidents = []

    fear_lookup = compute_fear_factor(coasters_df).to_dict()

    coaster_ids = set(coasters_df["Ride_Number"].dropna().unique())
    valid_park_numbers = set(rides_df["Park_Number"].dropna().unique())
    parks_df = parks_df[parks_df["Park_Number"].isin(valid_park_numbers)]

    # Split rides into coasters and others
    coasters_df = rides_df[rides_df["Ride_Number"].isin(coaster_ids)]
    others_df = rides_df[~rides_df["Ride_Number"].isin(coaster_ids)]

    while len(incidents) < count:
        park = parks_df.sample(n=1).iloc[0]
        park_number = park["Park_Number"]

        # 45% coasters, 55% others
        if random.random() < .45:
            source_df = coasters_df
        else:
            source_df = others_df

        # Replace park-specific filtering:
        matching_rides = coasters_df.copy() if random.random() < 0.45 else others_df.copy()
        weights = matching_rides["Ride_Number"].map(fear_lookup).fillna(0.1)

        ride = matching_rides.sample(n=1, weights=weights).iloc[0]

        # Still get the correct park via ride's Park_Number
        park = parks_df[parks_df["Park_Number"] == ride["Park_Number"]].iloc[0]

        incident = generate_incident_for_ride(ride, park, distributions, coaster_ids)
        if incident:
            incidents.append(incident)

    return incidents


def load_distributions(path="data/distributions.json"):
    with open(path, "r") as f:
        return json.load(f)
